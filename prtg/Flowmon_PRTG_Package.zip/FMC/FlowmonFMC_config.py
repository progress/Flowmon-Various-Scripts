# Flowmon FMC Config File
FLOWMON_REST_USER = "admin"
FLOWMON_REST_PASS = "admin"
INTERVAL = 300