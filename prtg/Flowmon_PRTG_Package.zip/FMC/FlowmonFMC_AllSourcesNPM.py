import json
import sys
import datetime
import requests
import FlowmonFMC_config
from prtg.sensor.result import CustomSensorResult
from prtg.sensor.units import ValueUnit


class FlowmonRestApi:
    def __init__(self):
        """ Set default attribute values only
            No arguments
        """
        self.__username = FlowmonFMC_config.FLOWMON_REST_USER
        self.__password = FlowmonFMC_config.FLOWMON_REST_PASS
        self.__interval_in_seconds = FlowmonFMC_config.INTERVAL
        self.__token = None
        self.__error = False
        self.__error_message = None
        self.__error_description = None

    def __init_auth_token(self, flowmon_host):
        """ Get an Authentication Token from Flowmon """
        payload = {"username": self.__username, "password": self.__password, "grant_type": "password",
                   "client_id": "invea-tech"}
        url = "https://" + flowmon_host + "/resources/oauth/token"

        try:
            response = requests.post(url, payload, verify=False, timeout=120)
        except requests.exceptions.Timeout as errt:
            self.__set_error("timeout_error", errt)
            return
        except requests.exceptions.ConnectionError as errc:
            self.__set_error("connection_error", errc)
            return
        if response.status_code == 200:
            r_json = response.json()
            self.__token = r_json["access_token"]
        else:
            self.__set_error(response.json()["error"], response.json()["error_description"])

    def get_last_time_interval(self):
        interval_in_minutes = int(self.__interval_in_seconds / 60)
        actual_time = datetime.datetime.now()
        actual_minutes = int(actual_time.strftime("%M"))
        rounded_minutes = actual_minutes - (actual_minutes % interval_in_minutes)
        interval_end = actual_time.replace(minute=rounded_minutes)
        interval_start = interval_end - datetime.timedelta(minutes=interval_in_minutes)
        interval_end = interval_end.strftime("%Y-%m-%d %H:%M")
        interval_start = interval_start.strftime("%Y-%m-%d %H:%M")
        return interval_start, interval_end

    def __get_response_from_api(self, flowmon_host, interval_start, interval_end, value):
        header = {"Authorization": "bearer " + self.__token}
        url = "https://" + flowmon_host + "/rest/fmc/analysis/chart"
        chart = {"measure": value, "protocol": "0"}
        npm = {"srt": True, "rtt": True, "rtr": True}
        payload = {"from": interval_start, "to": interval_end, "profile": "live", "chart": chart, "npm": npm}

        try:
            response = requests.get(url + "?search=" + json.dumps(payload), headers=header, verify=False, timeout=120)
        except requests.exceptions.Timeout as errt:
            self.__set_error("timeout_error", errt)
            return None
        except requests.exceptions.ConnectionError as errc:
            self.__set_error("connection_error", errc)
            return None
        if response.status_code == 200:
            events_list = json.loads(response.content.decode("utf-8"))
            return events_list
        elif response.status_code == 204:
            return None
        elif response.status_code == 405:
            self.__set_error(response.json()["code"], response.json()["message"])
            return None
        else:
            self.__set_error("error", response.json())
            return None

    def get_events(self, flowmon_host, value, interval_start, interval_end):
        """" Using GET request to get events aggregated by methods and ordered by priority """
        self.__init_auth_token(flowmon_host)
        if self.is_error():
            return None
        events_list = self.__get_response_from_api(flowmon_host, interval_start, interval_end, value)

        return events_list

    def __set_error(self, message, description):
        self.__error = True
        self.__error_message = message
        self.__error_description = description

    def is_error(self):
        return self.__error

    def error_print(self):
        result = CustomSensorResult(text="Error")
        result.error = str(self.__error_message) + ": " + str(self.__error_description)
        print(result.json_result)


class FlowmonFMCChannel:
    NPM_ID = ["live/npm-rtr", "live/npm-rtt", "live/npm-srt"]

    def __init__(self, channel):
        self.id = channel['channel']['id']
        self.name = channel['channel']['id']
        self.unit = None
        self.values = None
        self.set_unit_and_values(channel['values'])

    def set_unit_and_values(self, values):
        if self.id not in self.NPM_ID:
            return
        if self.id == "live/npm-rtr":
            self.unit = "#"
            self.values = round(values[0][1], 4)
        else:
            self.unit = "ms"
            self.values = round(values[0][1] / 1000, 4)


def calculate_events_count(charts, channel):
    for x in charts:
        if x == channel.id:
            charts[x][1] = channel.values
            charts[x][2] = channel.unit


def result_print(charts):
    """ Using PRTG library to create sensor and its channels """
    result = CustomSensorResult(text="OK")
    for x in charts:
        result.add_channel(name="Average " + charts[x][0], value=charts[x][1], unit=charts[x][2], is_float=1)
    print(result.json_result)


def main():
    prtg_data = json.loads(sys.argv[1])
    flowmon_host = prtg_data['host']

    request_data = "flows"

    charts = {"live/npm-srt": ["Server Response Time (SRT)", 0, ""],
              "live/npm-rtt": ["Round Trip Time (RTT)", 0, ""],
              "live/npm-rtr": ["Retransmissions (RTR)", 0, ""]}

    api_connector = FlowmonRestApi()
    time_start, time_end = api_connector.get_last_time_interval()

    events = api_connector.get_events(flowmon_host, request_data, time_start, time_end)

    if api_connector.is_error():
        api_connector.error_print()
        return

    if events is not None:
        for x in events:
            channel = FlowmonFMCChannel(x)
            calculate_events_count(charts, channel)
    result_print(charts)


if __name__ == "__main__":
    main()
