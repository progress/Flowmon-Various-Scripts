# Flowmon ADS Config File
FLOWMON_REST_USER = "admin"
FLOWMON_REST_PASS = "admin"
ADS_PERSPECTIVE = 3
INTERVAL = 300

